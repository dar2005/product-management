import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CtrylistComponent } from './ctrylist.component';

describe('CtrylistComponent', () => {
  let component: CtrylistComponent;
  let fixture: ComponentFixture<CtrylistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CtrylistComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CtrylistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
