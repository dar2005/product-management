import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-ctrylist',
  standalone: true,
  imports: [],
  templateUrl: './ctrylist.component.html',
  styleUrl: './ctrylist.component.css'
})
export class CtrylistComponent {
  @Input("cname")
  ctryName: string = '';
}
