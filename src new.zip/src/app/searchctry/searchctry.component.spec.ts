import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SearchctryComponent } from './searchctry.component';

describe('SearchctryComponent', () => {
  let component: SearchctryComponent;
  let fixture: ComponentFixture<SearchctryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SearchctryComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(SearchctryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
