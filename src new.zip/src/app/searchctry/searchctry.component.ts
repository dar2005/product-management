import { Component } from '@angular/core';
import { CtrylistComponent } from '../ctrylist/ctrylist.component';
import { FormsModule } from '@angular/forms';
import { response } from '../countries';

@Component({
  selector: 'app-searchctry',
  standalone: true,
  imports: [CtrylistComponent,FormsModule],
  templateUrl: './searchctry.component.html',
  styleUrl: './searchctry.component.css'
})
export class SearchctryComponent {
  ctryName: string = '';
  constructor() {
    console.log(response);
  }
}
