import { Component } from '@angular/core';
import { Routes } from '@angular/router';
import { SearchctryComponent } from './searchctry/searchctry.component';

export const routes: Routes = [
    {path:'ctry',component:SearchctryComponent},
];
